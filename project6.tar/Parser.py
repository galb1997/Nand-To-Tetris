"""This file is part of nand2tetris, as taught in The Hebrew University,
and was written by Aviv Yaish according to the specifications given in  
https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0 
Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/).
"""
import typing
A_COMMAND = "A_COMMAND"
C_COMMAND = "C_COMMAND"
L_COMMAND = "L_COMMAND"
A_SYMBOL = "@"
L_SYMBOL = "("
L_STRIP = "(, )"
JUMP_SYMBOL = ";"
EQUAL = "="
NULL = "null"


class Parser:
    """Encapsulates access to the input code. Reads and assembly language 
    command, parses it, and provides convenient access to the commands 
    components (fields and symbols). In addition, removes all white space and 
    comments.
    """

    @staticmethod
    def is_comment(line: str) -> bool:
        """
        this function checks if the line is a comment line
        meaning starts with "//"
        :param line: given line string
        :return: true if comment, false otherwise
        """
        line = line.strip()
        return line.startswith('//')

    @staticmethod
    def is_empty(line: str) -> bool:
        """
        this function checks if the line is a comment line
        meaning all kinds of white spaces
        :param line: given string line
        :return: true if empty, false otherwise
        """
        line = line.strip()
        return not line

    def __init__(self, input_file: typing.TextIO) -> None:
        """Opens the input file and gets ready to parse it.

        Args:
            input_file (typing.TextIO): input file.
        """
        input_lines = input_file.read().splitlines()
        self._command_list = []
        for line in input_lines:
            if (not self.is_comment(line)) and (not self.is_empty(line)):
                line = line.split("//")[0]
                line = line.replace(" ", "")
                self._command_list.append(line)
        self._command_counter = 0
        self._current_line = self._command_list[self._command_counter]

    def has_more_commands(self) -> bool:
        """Are there more commands in the input?

        Returns:
            bool: True if there are more commands, False otherwise.
        """
        return self._command_counter + 1 < len(self._command_list)

    def advance(self) -> None:
        """Reads the next command from the input and makes it the current command.
        Should be called only if has_more_commands() is true.
        """
        if self.has_more_commands():
            self._command_counter += 1
            self._current_line = self._command_list[self._command_counter]

    def command_type(self) -> str:
        """
        Returns:
            str: the type of the current command:
            "A_COMMAND" for @Xxx where Xxx is either a symbol or a decimal number
            "C_COMMAND" for dest=comp;jump
            "L_COMMAND" (actually, pseudo-command) for (Xxx) where Xxx is a symbol
        """
        if self._current_line[0] == A_SYMBOL:
            return A_COMMAND
        elif self._current_line[0] == L_SYMBOL:
            return L_COMMAND
        else:
            return C_COMMAND

    def symbol(self) -> str:
        """
        Returns:
            str: the symbol or decimal Xxx of the current command @Xxx or
            (Xxx). Should be called only when command_type() is "A_COMMAND" or 
            "L_COMMAND".
        """
        if self.command_type() == A_COMMAND:
            return self._current_line.strip(A_SYMBOL)
        elif self.command_type() == L_COMMAND:
            return self._current_line.strip(L_STRIP)

    def dest(self) -> str:
        """
        Returns:
            str: the dest mnemonic in the current C-command. Should be called 
            only when commandType() is "C_COMMAND".
        """
        split1 = self._current_line.split(EQUAL)
        if len(split1) > 1:
            return (self._current_line.split(EQUAL))[0]
        else:
            return NULL

    def comp(self) -> str:
        """
        Returns:
            str: the comp mnemonic in the current C-command. Should be called 
            only when commandType() is "C_COMMAND".
        """
        split1 = self._current_line.split(EQUAL)
        if len(split1) > 1:
            return split1[1].split(JUMP_SYMBOL, 1)[0]
        return split1[0].split(JUMP_SYMBOL, 1)[0]

    def jump(self) -> str:
        """
        Returns:
            str: the jump mnemonic in the current C-command. Should be called 
            only when commandType() is "C_COMMAND".
        """
        result = self._current_line.split(JUMP_SYMBOL, 1)
        if len(result) == 1:
            return NULL
        else:
            return result[1]

    def restart(self) -> None:
        """
        we use this function in order to re-read our file
        :return: None
        """
        self._command_counter = 0
        self._current_line = self._command_list[self._command_counter]





