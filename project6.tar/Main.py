"""This file is part of nand2tetris, as taught in The Hebrew University,
and was written by Aviv Yaish according to the specifications given in  
https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0 
Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/).
"""
import os
import sys
import typing
from SymbolTable import SymbolTable
from Parser import Parser
from Code import Code

L_COMMAND = "L_COMMAND"
A_COMMAND = "A_COMMAND"
C_COMMAND = "C_COMMAND"
C_COMMAND_START = "111"
SHIFT_LEFT = "<<"
SHIFT_RIGHT = ">>"
SHIFT_COMMAND_START = "101"


def is_shift(comp: str) -> bool:
    """
    this function check if the comp is shift command,
    meaning ends with "<<" or ">>"
    :param comp: a given comp command as string
    :return: true if shift-command, false otherwise
    """
    if comp.endswith(SHIFT_LEFT) or comp.endswith(SHIFT_RIGHT):
        return True
    return False


def assemble_file(
        input_file: typing.TextIO, output_file: typing.TextIO) -> None:
    """Assembles a single file.

    Args:
        input_file (typing.TextIO): the file to assemble.
        output_file (typing.TextIO): writes all output to this file.
    """
    # we will use the two-pass implementation
    #
    # *Initialization*
    # Initialize the symbol table with all the predefined symbols and their
    # pre-allocated RAM addresses, according to section 6.2.3 of the book.

    symbol_table = SymbolTable()

    # *First Pass*
    lines_counter = 0
    my_parser = Parser(input_file)
    is_first = 1
    while my_parser.has_more_commands():
        if not is_first:
            my_parser.advance()
        else:
            is_first = 0
        if my_parser.command_type() == L_COMMAND:
            symbol_table.add_entry(my_parser.symbol(), lines_counter)
        else:
            lines_counter += 1

    # *Second Pass*
    my_parser.restart()
    memory_counter = 16
    is_first = 1
    while my_parser.has_more_commands():
        if not is_first:
            my_parser.advance()
        else:
            is_first = 0
        command = ""
        if my_parser.command_type() == A_COMMAND:
            symbol = my_parser.symbol()
            if not symbol.isnumeric():
                if not symbol_table.contains(symbol):
                    symbol_table.add_entry(symbol, memory_counter)
                    memory_counter += 1
                symbol = symbol_table.get_address(symbol)
            command = bin(int(symbol))[2:].zfill(16)
        elif my_parser.command_type() == C_COMMAND:
            if is_shift(my_parser.comp()):
                command = SHIFT_COMMAND_START
            else:
                command = C_COMMAND_START
            command += Code.comp(my_parser.comp()) + \
                       Code.dest(my_parser.dest()) + \
                       Code.jump(my_parser.jump())
        if command:
            output_file.write(command + "\n")


if "__main__" == __name__:
    # Parses the input path and calls assemble_file on each input file.
    # This opens both the input and the output files!
    # Both are closed automatically when the code finishes running.
    # If the output file does not exist, it is created automatically in the
    # correct path, using the correct filename.
    if not len(sys.argv) == 2:
        sys.exit("Invalid usage, please use: Assembler <input path>")
    argument_path = os.path.abspath(sys.argv[1])
    if os.path.isdir(argument_path):
        files_to_assemble = [
            os.path.join(argument_path, filename)
            for filename in os.listdir(argument_path)]
    else:
        files_to_assemble = [argument_path]
    for input_path in files_to_assemble:
        filename, extension = os.path.splitext(input_path)
        if extension.lower() != ".asm":
            continue
        output_path = filename + ".hack"
        with open(input_path, 'r') as input_file, \
                open(output_path, 'w') as output_file:
            assemble_file(input_file, output_file)
