"""This file is part of nand2tetris, as taught in The Hebrew University,
and was written by Aviv Yaish according to the specifications given in  
https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0 
Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/).
"""
import typing


class CompilationEngine:
    """Gets input from a JackTokenizer and emits its parsed structure into an
    output stream.
    """

    def __init__(self, input_stream: typing.TextIO,
                 output_stream: typing.TextIO) -> None:
        """
        Creates a new compilation engine with the given input and output. The
        next routine called must be compileClass()
        :param input_stream: The input stream.
        :param output_stream: The output stream.
        """
        self._text_by_line = input_stream.readlines()
        self._token = []
        self._counter = 0
        for line in self._text_by_line:
            mid_line = line.split(">")[1]
            mid_line_2 = mid_line.split("<")[0]
            self._token.append(mid_line_2[1: len(mid_line_2) - 1])
        self._output_stream = output_stream
        self._current_token = self._token[self._counter]

    def eat(self) -> None:
        self._output_stream.write(self._text_by_line[self._counter])
        if self._counter < len(self._token) - 1:
            self._counter += 1
            self._current_token = self._token[self._counter]

    def compile_class(self) -> None:
        """Compiles a complete class."""
        self._output_stream.write('<class>\n')
        self.eat()  # class
        self.eat()  # class name
        self.eat()  # "{"
        while self._current_token not in ['constructor', 'function', 'method', "}"]:
            self.compile_class_var_dec()
        while self._current_token != "}":
            self.compile_subroutine()
        self.eat()  # "}"
        self._output_stream.write('</class>\n')

    def compile_class_var_dec(self) -> None:
        """Compiles a static declaration or a field declaration."""
        self._output_stream.write('<classVarDec>\n')
        while self._current_token != ';':
            self.eat()
        self.eat()
        self._output_stream.write('</classVarDec>\n')

    def compile_subroutine(self) -> None:
        """Compiles a complete method, function, or constructor."""
        self._output_stream.write('<subroutineDec>\n')
        self.eat()  # function|method|constructor
        self.eat()  # void|type
        self.eat()  # subroutineName
        self.eat()  # "("
        self.compile_parameter_list()
        self.eat()  # ")"
        self.subroutine_body()
        self._output_stream.write('</subroutineDec>\n')

    def subroutine_body(self) -> None:
        self._output_stream.write('<subroutineBody>\n')
        self.eat()  # "{"
        while self._current_token not in ["if", "let", "while", "return", "do"]:
            self.compile_var_dec()
        self.compile_statements()
        self.eat()  # "}"
        self._output_stream.write('</subroutineBody>\n')

    def compile_parameter_list(self) -> None:
        """Compiles a (possibly empty) parameter list, not including the 
        enclosing "()".
        """
        self._output_stream.write('<parameterList>\n')
        while self._current_token != ")":
            self.eat()  # for each type varName
        self._output_stream.write('</parameterList>\n')

    def compile_var_dec(self) -> None:
        """Compiles a var declaration."""
        self._output_stream.write('<varDec>\n')
        while self._current_token != ";":
            self.eat()
        self.eat()
        self._output_stream.write('</varDec>\n')

    def compile_statements(self) -> None:
        """Compiles a sequence of statements, not including the enclosing 
        "{}".
        """
        self._output_stream.write('<statements>\n')
        while self._current_token in ["if", "let", "while", "return", "do"]:
            if self._current_token == "if":
                self.compile_if()
            elif self._current_token == "let":
                self.compile_let()
            elif self._current_token == "while":
                self.compile_while()
            elif self._current_token == "return":
                self.compile_return()
            elif self._current_token == "do":
                self.compile_do()
        self._output_stream.write('</statements>\n')

    def compile_do(self) -> None:
        """Compiles a do statement."""
        self._output_stream.write('<doStatement>\n')
        self.eat()  # do
        while self._current_token != "(":
            self.eat()
        self.eat()  # "("
        self.compile_expression_list()
        self.eat()  # ")"
        self.eat()  # ";"
        self._output_stream.write('</doStatement>\n')

    def compile_let(self) -> None:
        """Compiles a let statement."""
        self._output_stream.write('<letStatement>\n')
        self.eat()  # let
        self._output_stream.write(
            "<identifier> " + self._current_token + " </identifier>\n") # varName
        if self._counter < len(self._token) - 1:
            self._counter += 1
            self._current_token = self._token[self._counter]
        if self._current_token == '[':
            self.eat()  # "["
            self.compile_expression()
            self.eat()  # "]"
        self.eat()  # "="
        self.compile_expression()
        self.eat()  # ";"
        self._output_stream.write('</letStatement>\n')

    def compile_while(self) -> None:
        """Compiles a while statement."""
        self._output_stream.write('<whileStatement>\n')
        self.eat()  # while
        self.eat()  # "("
        self.compile_expression()
        self.eat()  # ")"
        self.eat()  # "{"
        self.compile_statements()
        self.eat()  # "}"
        self._output_stream.write('</whileStatement>\n')

    def compile_return(self) -> None:
        """Compiles a return statement."""
        self._output_stream.write('<returnStatement>\n')
        self.eat()  # return
        if self._current_token != ";":
            self.compile_expression()
        self.eat()  # ";"
        self._output_stream.write('</returnStatement>\n')

    def compile_if(self) -> None:
        """Compiles a if statement, possibly with a trailing else clause."""
        self._output_stream.write('<ifStatement>\n')
        self.eat()  # if
        self.eat()  # "("
        self.compile_expression()
        self.eat()  # ")"
        self.eat()  # "{"
        self.compile_statements()
        self.eat()  # "}"
        if self._current_token == "else":
            self.eat()  # "else"
            self.eat()  # "{"
            self.compile_statements()
            self.eat()  # "}"
        self._output_stream.write('</ifStatement>\n')

    def compile_expression(self) -> None:
        """Compiles an expression."""
        self._output_stream.write('<expression>\n')
        self.compile_term()
        while self._current_token in ['+', '-', '*', '/', '|', '&lt;', '&gt;', '&quot;', '&amp;', '=', '^', '#']:
            self.eat()  # op
            self.compile_term()
        self._output_stream.write('</expression>\n')

    def compile_term(self) -> None:
        """Compiles a term. 
        This routine is faced with a slight difficulty when
        trying to decide between some of the alternative parsing rules.
        Specifically, if the current token is an identifier, the routing must
        distinguish between a variable, an array entry, and a subroutine call.
        A single look-ahead token, which may be one of "[", "(", or "." suffices
        to distinguish between the three possibilities. Any other token is not
        part of this term and should not be advanced over.
        """
        self._output_stream.write('<term>\n')
        if self._current_token == "(":
            self.eat()  # "("
            self.compile_expression()
            self.eat()  # ")"
        elif self._current_token in ['-', '~']:
            self.eat()  # unaryOp
            self.compile_term()
        else:
            self.eat()
            if self._current_token == "[":
                self.eat()  # "["
                self.compile_expression()
                self.eat()  # "]"
            elif self._current_token == "(":
                self.eat()  # "("
                self.compile_expression_list()
                self.eat()  # ")"
            elif self._current_token == ".":
                self.eat()  # "."
                self.eat()  # subroutineName
                self.eat()  # "("
                self.compile_expression_list()
                self.eat()  # ")"
        self._output_stream.write('</term>\n')

    def compile_expression_list(self) -> None:
        """Compiles a (possibly empty) comma-separated list of expressions."""
        self._output_stream.write('<expressionList>\n')
        while self._current_token != ")":
            if self._current_token == ",":
                self.eat()
            else:
                self.compile_expression()
        self._output_stream.write('</expressionList>\n')
