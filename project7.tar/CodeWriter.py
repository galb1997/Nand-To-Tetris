"""This file is part of nand2tetris, as taught in The Hebrew University,
and was written by Aviv Yaish according to the specifications given in  
https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0 
Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/).
"""
import typing

C_POP = "C_POP"
A_COMMAND = "@"
TEMP = "temp"
LOCAL = "local"
ARGUMENT = "argument"
CONSTANT = "constant"
POINTER = "pointer"
THAT = "that"
THIS = "this"
STATIC = "static"
C_PUSH = "C_PUSH"
PUSH_END = ["@SP\n", "A=M\n", "M=D\n", "@SP\n", "M=M+1\n"]
PUSH_DIR = {LOCAL: ["D=A\n", "@LCL\n", "A=M+D\n", "D=M\n"],
            THAT: ["D=A\n", "@THAT\n", "A=M+D\n", "D=M\n"],
            THIS: ["D=A\n", "@THIS\n", "A=M+D\n", "D=M\n"],
            ARGUMENT: ["D=A\n", "@ARG\n", "A=M+D\n", "D=M\n"],
            CONSTANT: ["D=A\n"], TEMP: ["D=A\n", "@5\n", "A=D+A\n", "D=M\n"],
            STATIC: ["D=M\n"],
            POINTER: ["D=A\n", "@3\n", "A=D+A\n", "D=M\n"]}
POP_START = ["@SP\n", "A=M-1\n", "D=M\n", "@SP\n", "M=M-1\n", "@13\n", "M=D\n"]
POP_DIR = {LOCAL: ["D=A\n", "@LCL\n", "D=M+D\n", "@14\n", "M=D\n", "@13\n",
                   "D=M\n", "@14\n", "A=M\n", "M=D\n"],
           THAT: ["D=A\n", "@THAT\n", "D=M+D\n", "@14\n", "M=D\n", "@13\n",
                  "D=M\n", "@14\n", "A=M\n", "M=D\n"],
           THIS: ["D=A\n", "@THIS\n", "D=M+D\n", "@14\n", "M=D\n", "@13\n",
                  "D=M\n", "@14\n", "A=M\n", "M=D\n"],
           ARGUMENT: ["D=A\n", "@ARG\n", "D=M+D\n", "@14\n", "M=D\n", "@13\n",
                      "D=M\n", "@14\n", "A=M\n", "M=D\n"],
           TEMP: ["D=A\n", "@5\n", "D=D+A\n", "@14\n", "M=D\n", "@13\n",
                  "D=M\n", "@14\n", "A=M\n", "M=D\n"],
           POINTER: ["D=A\n", "@3\n", "D=D+A\n", "@14\n", "M=D\n", "@13\n",
                     "D=M\n", "@14\n", "A=M\n", "M=D\n"]}
ARITHMETIC1_DIR = {"add": ["@SP\n", "A=M-1\n", "D=M\n", "@SP\n", "A=M-1\n",
                           "A=A-1\n", "M=M+D\n", "@SP\n", "M=M-1\n"],
                   "sub": ["@SP\n", "A=M-1\n", "D=M\n", "@SP\n", "A=M-1\n",
                           "A=A-1\n", "M=M-D\n", "@SP\n", "M=M-1\n"],
                   "or": ["@SP\n", "A=M-1\n", "D=M\n", "@SP\n", "A=M-1\n",
                          "A=A-1\n", "M=D|M\n", "@SP\n", "M=M-1\n"],
                   "not": ["@SP\n", "A=M-1\n", "M=!M\n"],
                   "and": ["@SP\n", "A=M-1\n", "D=M\n", "@SP\n", "A=M-1\n",
                           "A=A-1\n", "M=D&M\n", "@SP\n", "M=M-1\n"],
                   "neg": ["@SP\n", "A=M-1\n", "D=M\n", "M=M-D\n", "M=M-D\n"]}
SHIFT_DIR = {"shiftleft": ["@SP\n", "A=M-1\n", "M=M<<\n"],
             "shiftright": ["@SP\n", "A=M-1\n", "M=M>>\n"]}


class CodeWriter:
    """Translates VM commands into Hack assembly code."""

    def __init__(self, output_stream: typing.TextIO) -> None:
        """Initializes the CodeWriter.

        Args:
            output_stream (typing.TextIO): output stream.
        """
        self._output_file = output_stream
        self._file_name = ""
        self._counter = 0

    def set_file_name(self, filename: str) -> None:
        """Informs the code writer that the translation of a new VM file is 
        started.

        Args:
            filename (str): The name of the VM file.
        """
        self._file_name = filename

    def get_arithmetic2(self, key: str) -> []:
        """
        this function gets the right assembly command to 3 vm commands: eq, lt, gt
        :param key: the required vm command
        :return: the fit assembly command
        """
        arithmetic2_dir = {"eq": ["@SP\n", "A=M-1\n", "D=M\n",
                                  "@LABEL 1 " + str(self._counter) + "\n", "D;JGT\n",
                                  "@SP\n", "A=M-1\n",
                                  "A=A-1\n", "D=M\n",
                                  "@LABEL 2 " + str(self._counter) + "\n",
                                  "D;JLT\n", "@FALSE " + str(self._counter) + "\n",
                                  "0;JMP\n",
                                  "(LABEL 1 " + str(self._counter) + ")\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "D=M\n",
                                  "@LABEL 2 " + str(self._counter) + "\n",
                                  "D;JGT\n", "@FALSE " + str(self._counter) + "\n",
                                  "0;JMP\n",
                                  "(LABEL 2 " + str(self._counter) + ")\n",
                                  "@SP\n", "A=M-1\n", "D=M\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "D=M-D\n", "@TRUE " + str(self._counter) + "\n",
                                  "D;JEQ\n", "(FALSE " + str(self._counter) + ")\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "M=0\n", "@END " + str(self._counter) + "\n",
                                  "0;JMP\n", "(TRUE " + str(self._counter) + ")\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "M=-1\n", "(END " + str(self._counter) + ")\n",
                                  "@SP\n", "M=M-1\n"],

                           "lt": ["@SP\n", "A=M-1\n", "D=M\n",
                                  "@LABEL 1 " + str(self._counter) + "\n",
                                  "D;JGT\n",
                                  "@SP\n", "A=M-1\n",
                                  "A=A-1\n", "D=M\n",
                                  "@LABEL 2 " + str(self._counter) + "\n",
                                  "D;JLT\n", "@FALSE " + str(self._counter) + "\n",
                                  "0;JMP\n",
                                  "(LABEL 1 " + str(self._counter) + ")\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "D=M\n",
                                  "@LABEL 2 " + str(self._counter) + "\n",
                                  "D;JGT\n", "@TRUE " + str(self._counter) + "\n",
                                  "0;JMP\n",
                                  "(LABEL 2 " + str(self._counter) + ")\n",
                                  "@SP\n", "A=M-1\n", "D=M\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "D=M-D\n", "@TRUE " + str(self._counter) + "\n",
                                  "D;JLT\n", "(FALSE " + str(self._counter) + ")\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "M=0\n", "@END " + str(self._counter) + "\n",
                                  "0;JMP\n", "(TRUE " + str(self._counter) + ")\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "M=-1\n", "(END " + str(self._counter) + ")\n",
                                  "@SP\n", "M=M-1\n"],

                           "gt": ["@SP\n", "A=M-1\n", "D=M\n",
                                  "@LABEL 1 " + str(self._counter) + "\n",
                                  "D;JGT\n",
                                  "@SP\n", "A=M-1\n",
                                  "A=A-1\n", "D=M\n",
                                  "@LABEL 2 " + str(self._counter) + "\n",
                                  "D;JLT\n", "@TRUE " + str(self._counter) + "\n",
                                  "0;JMP\n",
                                  "(LABEL 1 " + str(self._counter) + ")\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "D=M\n",
                                  "@LABEL 2 " + str(self._counter) + "\n",
                                  "D;JGT\n", "@FALSE " + str(self._counter) + "\n",
                                  "0;JMP\n",
                                  "(LABEL 2 " + str(self._counter) + ")\n",
                                  "@SP\n", "A=M-1\n", "D=M\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "D=M-D\n", "@TRUE " + str(self._counter) + "\n",
                                  "D;JGT\n", "(FALSE " + str(self._counter) + ")\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "M=0\n", "@END " + str(self._counter) + "\n",
                                  "0;JMP\n", "(TRUE " + str(self._counter) + ")\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "M=-1\n", "(END " + str(self._counter) + ")\n",
                                  "@SP\n", "M=M-1\n"]}
        return arithmetic2_dir[key]

    def write_arithmetic(self, command: str) -> None:
        """Writes the assembly code that is the translation of the given 
        arithmetic command.

        Args:
            command (str): an arithmetic command.
        """
        self._counter += 1
        self._output_file.write("//" + command + "\n")
        to_write = []
        if command in ["gt", "lt", "eq"]:
            to_write += self.get_arithmetic2(command)
        elif command in ["shiftleft", "shiftright"]:
            to_write += SHIFT_DIR[command]
        else:
            to_write += ARITHMETIC1_DIR[command]
        self._output_file.writelines(to_write)

    def write_push_pop(self, command: str, segment: str, index: int) -> None:
        """Writes the assembly code that is the translation of the given 
        command, where command is either C_PUSH or C_POP.

        Args:
            command (str): "C_PUSH" or "C_POP".
            segment (str): the memory segment to operate on.
            index (int): the index in the memory segment.
        """
        to_write = []
        self._output_file.write("//" + command + " " + segment + " " + str(index) + "\n")
        if command == C_PUSH:
            if segment == STATIC:
                to_write.append(A_COMMAND + self._file_name + "." + str(index) + "\n")
            else:
                to_write.append(A_COMMAND + str(index) + "\n")
            to_write += PUSH_DIR[segment]
            to_write += PUSH_END

        if command == C_POP:
            to_write += POP_START
            if segment == STATIC:
                to_write += ["@13\n", "D=M\n", "@" + self._file_name +
                             "." + str(index) + "\n", "M=D\n"]
            else:
                to_write.append("@" + str(index) + "\n")
                to_write += POP_DIR[segment]
        self._output_file.writelines(to_write)

    def close(self) -> None:
        """Closes the output file."""
        self._output_file.close()
