"""This file is part of nand2tetris, as taught in The Hebrew University,
and was written by Aviv Yaish according to the specifications given in  
https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0 
Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/).
"""
import typing
import SymbolTable
import VMWriter

DIR_OP = {'+': "ADD", '-': "SUB", "|": "OR", "&lt;": "LT",
          "&gt;": "GT", "&quot;": "EQ", "&amp;": "AND",
          "#": "shiftright", "^": "shiftleft", "=": "EQ"}

TEMP = "TEMP"
THAT = "THAT"
POINTER = "POINTER"
ADD = "ADD"


class CompilationEngine:
    """Gets input from a JackTokenizer and emits its parsed structure into an
    output stream.
    """

    def __init__(self, input_stream: typing.TextIO,
                 output_stream: typing.TextIO) -> None:
        """
        Creates a new compilation engine with the given input and output. The
        next routine called must be compileClass()
        :param input_stream: The input stream.
        :param output_stream: The output stream.
        """
        self._text_by_line = input_stream.readlines()
        self._token = []
        self._token_type = []
        self._counter = 0
        self._label_counter = 1
        for line in self._text_by_line:
            token_type = line.split(">")[0]
            mid_line = line.split(">")[1]
            mid_line_2 = mid_line.split("<")[0]
            self._token.append(mid_line_2[1: len(mid_line_2) - 1])
            self._token_type.append(token_type[1:])
        self._output_stream = output_stream
        self._current_token = self._token[self._counter]
        self._current_type = self._token_type[self._counter]
        self._my_symbol_table = SymbolTable.SymbolTable()
        self._my_writer = VMWriter.VMWriter(output_stream)
        self._class_name = ""

    def eat(self) -> None:
        if self._counter < len(self._token) - 1:
            self._counter += 1
            self._current_token = self._token[self._counter]
            self._current_type = self._token_type[self._counter]

    def compile_class(self) -> None:
        """Compiles a complete class."""
        self.eat()  # class
        self._class_name = self._current_token
        self.eat()  # class name
        self.eat()  # "{"
        while self._current_token not in ['constructor', 'function', 'method',
                                          "}"]:
            self.compile_class_var_dec()
        while self._current_token != "}":
            self.compile_subroutine()
            self._my_symbol_table.start_subroutine()
        self.eat()  # "}"

    def compile_class_var_dec(self) -> None:
        """Compiles a static declaration or a field declaration."""
        while self._current_token != ';':
            kind = self._current_token.upper()
            self.eat()
            type = self._current_token
            self.eat()
            var_name = self._current_token
            self._my_symbol_table.define(var_name, type, kind)
            self.eat()
            while self._current_token == ",":
                self.eat()
                var_name = self._current_token
                self._my_symbol_table.define(var_name, type, kind)
                self.eat()
        self.eat()

    def compile_subroutine(self) -> None:
        """Compiles a complete method, function, or constructor."""
        is_void = False
        subroutine_type = self._current_token
        self.eat()  # function|method|constructor
        if self._current_token == "void":
            is_void = True
        self.eat()  # void|type
        function_name = self._class_name + "." + self._current_token
        self.eat()  # subroutineName
        self.eat()  # "("
        if subroutine_type == "method":
            self._my_symbol_table.define("this", self._class_name, "ARGUMENT")
        self.compile_parameter_list()
        self.eat()  # ")"
        self.subroutine_var_dec()
        num_locals = self._my_symbol_table.var_count("VAR")
        self._my_writer.write_function(function_name, num_locals)
        if subroutine_type == "constructor":
            self.constructor_body()
        elif subroutine_type == "method":
            self.method_body()
        self.subroutine_body()

    def subroutine_var_dec(self) -> None:
        self.eat()  # "{"
        while self._current_token not in ["if", "let", "while", "return",
                                          "do"]:
            self.compile_var_dec()

    def subroutine_body(self) -> None:
        self.compile_statements()
        self.eat()  # "}"

    def compile_parameter_list(self) -> int:
        """Compiles a (possibly empty) parameter list, not including the 
        enclosing "()".
        """
        args_counter = 0
        while self._current_token != ")":
            args_counter += 1
            type = self._current_token
            self.eat()
            var_name = self._current_token
            self._my_symbol_table.define(var_name, type, "ARGUMENT")
            self.eat()
            while self._current_token == ",":
                args_counter += 1
                self.eat()
                type = self._current_token
                self.eat()
                var_name = self._current_token
                self._my_symbol_table.define(var_name, type, "ARGUMENT")
                self.eat()
        return args_counter

    def compile_var_dec(self) -> None:
        """Compiles a var declaration."""
        while self._current_token != ";":
            self.eat()
            type = self._current_token
            self.eat()
            var_name = self._current_token
            self._my_symbol_table.define(var_name, type, "VAR")
            self.eat()
            while self._current_token == ",":
                self.eat()
                var_name = self._current_token
                self._my_symbol_table.define(var_name, type, "VAR")
                self.eat()
        self.eat()

    def compile_statements(self) -> None:
        """Compiles a sequence of statements, not including the enclosing 
        "{}".
        """
        while self._current_token in ["if", "let", "while", "return", "do"]:
            if self._current_token == "if":
                self.compile_if()
            elif self._current_token == "let":
                self.compile_let()
            elif self._current_token == "while":
                self.compile_while()
            elif self._current_token == "return":
                self.compile_return()
            elif self._current_token == "do":
                self.compile_do()

    def compile_do(self) -> None:
        """Compiles a do statement."""
        self.eat()  # do
        function_name = self._current_token
        self.eat()
        is_method = False
        if self._current_token == ".":
            arg_0 = function_name
            self.eat()
            function_name = self._current_token
            kind = self._my_symbol_table.kind_of(arg_0)
            if kind != 'None':
                is_method = True
                index = self._my_symbol_table.index_of(arg_0)
                self._my_writer.write_push(kind, index)
                type = self._my_symbol_table.type_of(arg_0)
                function_name = type + "." + function_name
            else:
                function_name = arg_0 + "." + function_name
            self.eat()
        else:
            is_method = True
            function_name = self._class_name + "." + function_name
            self._my_writer.write_push("POINTER", 0)
        self.eat()  # "("
        num_args = self.compile_expression_list()
        if is_method:
            num_args += 1
        self._my_writer.write_call(function_name, num_args)
        self._my_writer.write_pop("TEMP", 0)
        self.eat()  # ")"
        self.eat()  # ";"

    def compile_let(self) -> None:
        """Compiles a let statement."""
        self.eat()  # let
        var_name = self._current_token
        kind = self._my_symbol_table.kind_of(var_name)
        index = self._my_symbol_table.index_of(var_name)
        self.eat()  # varName
        if self._current_token == '[':
            self.eat()  # "["
            self._my_writer.write_push(kind, index)
            self.compile_expression()
            self._my_writer.write_arithmetic(ADD)
            self.eat()  # "]"
            self.eat()  # "="
            self.compile_expression()
            self._my_writer.write_pop(TEMP, 0)
            self._my_writer.write_pop(POINTER, 1)
            self._my_writer.write_push(TEMP, 0)
            self._my_writer.write_pop(THAT, 0)
        else:
            self.eat()
            self.compile_expression()
            self._my_writer.write_pop(kind, index)
        self.eat()  # ";"

    def compile_while(self) -> None:
        """Compiles a while statement."""
        index_label_1 = self._label_counter
        index_label_2 = self._label_counter + 1
        self._label_counter += 2
        self._my_writer.write_label(self._class_name + ".L" + str(index_label_1))
        self.eat()  # while
        self.eat()  # "("
        self.compile_expression()
        self._my_writer.write_arithmetic("NOT")
        self._my_writer.write_if(self._class_name + ".L" + str(index_label_2))
        self.eat()  # ")"
        self.eat()  # "{"
        self.compile_statements()
        self._my_writer.write_goto(self._class_name + ".L" + str(index_label_1))
        self._my_writer.write_label(self._class_name + ".L" + str(index_label_2))
        self.eat()  # "}"

    def compile_return(self) -> None:
        """Compiles a return statement."""
        self.eat()  # return
        if self._current_token == ";":
            self._my_writer.write_push("CONSTANT", 0)
        else:
            self.compile_expression()
        self._my_writer.write_return()
        self.eat()  # ";"

    def compile_if(self) -> None:
        """Compiles a if statement, possibly with a trailing else clause."""
        index_label_1 = self._label_counter
        index_label_2 = self._label_counter + 1
        self._label_counter += 2
        self.eat()  # if
        self.eat()  # "("
        self.compile_expression()
        self._my_writer.write_arithmetic("NOT")
        self._my_writer.write_if(self._class_name + ".L" + str(index_label_1))
        self.eat()  # ")"
        self.eat()  # "{"
        self.compile_statements()
        self._my_writer.write_goto(self._class_name + ".L" + str(index_label_2))
        self._my_writer.write_label(self._class_name + ".L" + str(index_label_1))
        self.eat()  # "}"
        if self._current_token == "else":
            self.eat()  # "else"
            self.eat()  # "{"
            self.compile_statements()
            self.eat()  # "}"
        self._my_writer.write_label(self._class_name + ".L" + str(index_label_2))

    def compile_expression(self) -> None:
        """Compiles an expression."""
        self.compile_term()
        if self._current_token in ['+', '-', '*', '/', '|', '&lt;', '&gt;',
                                   '&quot;', '&amp;', '^', '#', '=']:
            op = self._current_token
            self.eat()  # op
            self.compile_expression()
            if op in DIR_OP:
                self._my_writer.write_arithmetic(DIR_OP[op])
            elif op == "*":
                self._my_writer.write_call("Math.multiply", 2)
            else:
                self._my_writer.write_call("Math.divide", 2)

    def compile_term(self) -> None:
        """Compiles a term. 
        This routine is faced with a slight difficulty when
        trying to decide between some of the alternative parsing rules.
        Specifically, if the current token is an identifier, the routing must
        distinguish between a variable, an array entry, and a subroutine call.
        A single look-ahead token, which may be one of "[", "(", or "."
        suffices to distinguish between the three possibilities. Any other
        token is not part of this term and should not be advanced over.
        """
        next_token = ""
        now_token = self._current_token
        if self._counter < len(self._token) - 1:
            next_token = self._token[self._counter + 1]
        now_type = self._current_type

        #  integer Constant
        if now_type == "integerConstant":
            self._my_writer.write_push("CONSTANT", int(now_token))
            self.eat()
            return

        #  string Constant
        elif now_type == "stringConstant":
            self._my_writer.write_push("CONSTANT", len(now_token))
            self._my_writer.write_call("String.new", 1)
            for char in now_token:
                self._my_writer.write_push("CONSTANT", ord(char))
                self._my_writer.write_call("String.appendChar", 2)
            self.eat()
            return

        #  keyWord Constant
        elif now_token == "true":
            self._my_writer.write_push("CONSTANT", 1)
            self._my_writer.write_arithmetic("NEG")
            self.eat()
            return
        elif now_token == "false" or now_token == "null":
            self._my_writer.write_push("CONSTANT", 0)
            self.eat()
            return
        elif now_token == "this":
            self._my_writer.write_push("POINTER", 0)
            self.eat()
            return

        #  var Name
        kind = self._my_symbol_table.kind_of(now_token)
        if kind != 'None' and next_token != ".":
            index = self._my_symbol_table.index_of(now_token)
            self._my_writer.write_push(kind, index)
            if next_token == "[":
                self.eat()  # "["
                self.eat()
                self.compile_expression()
                self._my_writer.write_arithmetic(ADD)
                self._my_writer.write_pop(POINTER, 1)
                self._my_writer.write_push(THAT, 0)

                # self.eat()  # "["
                # self._my_writer.write_push(kind, index)
                # self.compile_expression()
                # self._my_writer.write_arithmetic(ADD)
                # self.eat()  # "]"
                # self.eat()  # "="
                # self.compile_expression()
                # self._my_writer.write_pop(TEMP, 0)
                # self._my_writer.write_pop(POINTER, 1)
                # self._my_writer.write_push(TEMP, 0)
                # self._my_writer.write_pop(THAT, 0)

            self.eat()
            return

        #  unary Op term
        if now_token == "-":
            self.eat()
            self.compile_expression()
            self._my_writer.write_arithmetic("NEG")
            return
        elif now_token == "~":
            self.eat()
            self.compile_expression()
            self._my_writer.write_arithmetic("NOT")
            return

        elif now_token == "(":
            self.eat()  # "("
            self.compile_expression()
            self.eat()  # ")"
            return

        else:
            function_name = self._current_token
            self.eat()
            is_method = False
            if self._current_token == ".":
                arg_0 = function_name
                self.eat()
                function_name = self._current_token
                kind = self._my_symbol_table.kind_of(arg_0)
                if kind != 'None':
                    is_method = True
                    index = self._my_symbol_table.index_of(arg_0)
                    self._my_writer.write_push(kind, index)
                    type = self._my_symbol_table.type_of(arg_0)
                    function_name = type + "." + function_name
                else:
                    function_name = arg_0 + "." + function_name
                self.eat()
            else:
                is_method = True
                function_name = self._class_name + "." + function_name
                self._my_writer.write_push("POINTER", 0)
            self.eat()  # "("
            num_args = self.compile_expression_list()
            if is_method:
                num_args += 1
            self._my_writer.write_call(function_name, num_args)
            self.eat()  # ")"
            return

    def compile_expression_list(self) -> int:
        """Compiles a (possibly empty) comma-separated list of expressions."""
        count_args = 0
        while self._current_token != ")":
            if self._current_token == ",":
                self.eat()
            else:
                self.compile_expression()
                count_args += 1
        return count_args

    def constructor_body(self):
        num_args = self._my_symbol_table.var_count("FIELD")
        self._my_writer.write_push("CONSTANT", num_args)
        self._my_writer.write_call("Memory.alloc", 1)
        self._my_writer.write_pop("POINTER", 0)

    def method_body(self):
        self._my_writer.write_push("ARGUMENT", 0)
        self._my_writer.write_pop("POINTER", 0)
