"""This file is part of nand2tetris, as taught in The Hebrew University,
and was written by Aviv Yaish according to the specifications given in  
https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0 
Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/).
"""
import typing
import re

AMP_SIGN = '&'
QUOT_SIGN = '"'
GREATER_THEN_SIGN = '>'
LESS_THEN_SIGN = '<'
IDENTIFIER = "IDENTIFIER"
STRING_CONST = "STRING_CONST"
INT_CONST = "INT_CONST"
SYMBOL = "SYMBOL"
KEYWORD = "KEYWORD"
KEYWORD_LIST = ['class', 'constructor', 'function', 'method', 'field', 'static',
                'var', 'int', 'char', 'boolean', 'void', 'true', 'false', 'null', 'this',
                'let', 'do', 'if', 'else', 'while', 'return']
KEYWORD_DIR = {'class': "CLASS", 'constructor': "CONSTRUCTOR", 'function': "FUNCTION", 'method': "METHOD",
               'field': "FIELD", 'static': "STATIC", 'var': "VAR", 'int': "INT", 'char': "CHAR", 'boolean': "BOOLEAN",
               'void': "VOID", 'true': "TRUE", 'false': "FALSE", 'null': "NULL", 'this': "THIS",
               'let': "LET", 'do': "DO", 'if': "IF", 'else': "ELSE", 'while': "WHILE", 'return': "RETURN"}

SYMBOL_LIST = ['{', '}', '(', ')', '[', ']', '.', ',', ';', '+', '-', '*', '/', '&', '|', '<', '>',
               '=', '~', '^', '#']

COMMENT_REGEX1 = r"/\*(?:.*?\s*?)*?\*/"
COMMENT_REGEX2 = r"/\*\*(?:.*?\s*?)*?\*/"
COMMENT_REGEX3 = r"//.*?\n"
COMMENT_REGEX = [COMMENT_REGEX1, COMMENT_REGEX2, COMMENT_REGEX3]
STRING_REGEX = r"\"(?:.*?\s*?)*?\""
INTEGER_CONSTANT_REGEX = r"^\d{1,5}$"

SYMBOL_REGEX = "(\{|}|\(|\)|\[|\]|\.|,|;|\+|\-|\*|\/|&|\||<|>|=|#|^|~|\")"


class JackTokenizer:
    """Removes all comments from the input stream and breaks it
    into Jack language tokens, as specified by the Jack grammar.
    """

    def __init__(self, input_stream: typing.TextIO) -> None:
        """Opens the input stream and gets ready to tokenize it.

        Args:
            input_stream (typing.TextIO): input stream.
        """
        # open text file and read it to one string
        our_text = input_stream.read()

        # we put all strings in list in order to insert them back at the end
        # of the process
        self._all_strings = []
        index = 0
        while index < len(our_text):
            if our_text[index: index + 2] == "//":
                while our_text[index] != "\n":
                    index += 1
                    now_char = our_text[index]
            elif our_text[index: index + 2] == "/*":
                while our_text[index: index + 2] != "*/":
                    index += 1
            elif our_text[index] == '"':
                mid_string = ""
                index += 1
                while our_text[index] != '"':
                    mid_string += our_text[index]
                    index += 1
                self._all_strings.append(mid_string)
            index += 1

        # instead of each string in our text we will put 'a'
        mid_data = re.sub(STRING_REGEX, "'a'", our_text)
        our_text = mid_data

        # make the text string without any comment
        for regex in COMMENT_REGEX:
            mid_data = re.sub(regex, " ", our_text)
            our_text = mid_data

        # make the text without any spaces
        step1 = our_text.split()

        # split the symbols to different token
        step2 = []
        for token in step1:
            step2 += re.split(SYMBOL_REGEX, token)

        # putting back the fit strings
        # deleting all empty strings
        self._token = []
        counter = 0
        for i in range(len(step2) - 1):
            if step2[i] != "":
                if step2[i] == "'a'":
                    self._token.append(self._all_strings[counter])
                    counter += 1
                else:
                    self._token.append(step2[i])

        self._token_counter = -1
        self._current_token = self._token[self._token_counter]

    def has_more_tokens(self) -> bool:
        """Do we have more tokens in the input?

        Returns:
            bool: True if there are more tokens, False otherwise.
        """
        return self._token_counter + 1 < len(self._token)

    def advance(self) -> None:
        """Gets the next token from the input and makes it the current token. 
        This method should be called if has_more_tokens() is true. 
        Initially there is no current token.
        """
        if self.has_more_tokens():
            self._token_counter += 1
            self._current_token = self._token[self._token_counter]

    def token_type(self) -> str:
        """
        Returns:
            str: the type of the current token, can be
            "KEYWORD", "SYMBOL", "IDENTIFIER", "INT_CONST", "STRING_CONST"
        """
        if self._current_token in KEYWORD_LIST:
            return KEYWORD
        elif self._current_token in SYMBOL_LIST:
            return SYMBOL
        elif re.match(INTEGER_CONSTANT_REGEX, self._current_token):
            return INT_CONST
        elif self._current_token in self._all_strings:
            return STRING_CONST
        return IDENTIFIER

    def keyword(self) -> str:
        """
        Returns:
            str: the keyword which is the current token.
            Should be called only when token_type() is "KEYWORD".
            Can return "CLASS", "METHOD", "FUNCTION", "CONSTRUCTOR", "INT", 
            "BOOLEAN", "CHAR", "VOID", "VAR", "STATIC", "FIELD", "LET", "DO", 
            "IF", "ELSE", "WHILE", "RETURN", "TRUE", "FALSE", "NULL", "THIS"
        """
        return KEYWORD_DIR[self._current_token]

    def symbol(self) -> str:
        """
        Returns:
            str: the character which is the current token.
            Should be called only when token_type() is "SYMBOL".
        """
        if self.token_type() == SYMBOL:
            if self._current_token == LESS_THEN_SIGN:
                return "&lt;"
            if self._current_token == GREATER_THEN_SIGN:
                return "&gt;"
            elif self._current_token == QUOT_SIGN:
                return "&quot;"
            elif self._current_token == AMP_SIGN:
                return "&amp;"
            return self._current_token

    def identifier(self) -> str:
        """
        Returns:
            str: the identifier which is the current token.
            Should be called only when token_type() is "IDENTIFIER".
        """
        if self.token_type() == IDENTIFIER:
            return self._current_token

    def int_val(self) -> int:
        """
        Returns:
            str: the integer value of the current token.
            Should be called only when token_type() is "INT_CONST".
        """
        if self.token_type() == INT_CONST:
            return int(self._current_token)

    def string_val(self) -> str:
        """
        Returns:
            str: the string value of the current token, without the double 
            quotes. Should be called only when token_type() is "STRING_CONST".
        """
        if self.token_type() == STRING_CONST:
            return self._current_token
