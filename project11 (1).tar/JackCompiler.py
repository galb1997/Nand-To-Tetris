"""This file is part of nand2tetris, as taught in The Hebrew University,
and was written by Aviv Yaish according to the specifications given in  
https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0 
Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/).
"""
import io
import os
import sys
import typing
from CompilationEngine import CompilationEngine
from JackTokenizer import JackTokenizer
from SymbolTable import SymbolTable
from VMWriter import VMWriter

IDENTIFIER = "IDENTIFIER"
STRING_CONST = "STRING_CONST"
INT_CONST = "INT_CONST"
SYMBOL = "SYMBOL"
KEYWORD = "KEYWORD"
KEYWORD_DIR = {"CLASS":'class' , "CONSTRUCTOR":'constructor' , "FUNCTION":'function' , "METHOD":'method' ,
               "FIELD":'field' , "STATIC":'static' , "VAR":'var' , "INT":'int' , "CHAR":'char' , "BOOLEAN":'boolean' ,
               "VOID":'void' ,  "TRUE":'true', "FALSE":'false' , "NULL":'null' , "THIS":'this' ,
               "LET":'let' , "DO":'do' , "IF":'if' , "ELSE":'else' , "WHILE":'while' ,  "RETURN":'return'}


def compile_file(
        input_file: typing.TextIO, output_file: typing.TextIO) -> None:
    """Compiles a single file.

    Args:
        input_file (typing.TextIO): the file to compile.
        output_file (typing.TextIO): writes all output to this file.
    """
    my_jack_tokenizer = JackTokenizer(input_file)
    mid_file = io.StringIO()
    while my_jack_tokenizer.has_more_tokens():
        my_jack_tokenizer.advance()
        token_type = my_jack_tokenizer.token_type()
        if token_type == IDENTIFIER:
            mid_file.write("<identifier> " + my_jack_tokenizer.identifier() + " </identifier>\n")
        elif token_type == KEYWORD:
            mid_file.write("<keyword> " + KEYWORD_DIR[my_jack_tokenizer.keyword()] + " </keyword>\n")
        elif token_type == SYMBOL:
            mid_file.write("<symbol> " + my_jack_tokenizer.symbol() + " </symbol>\n")
        elif token_type == INT_CONST:
            mid_file.write("<integerConstant> " + str(my_jack_tokenizer.int_val()) + " </integerConstant>\n")
        elif token_type == STRING_CONST:
            mid_file.write("<stringConstant> " + my_jack_tokenizer.string_val() + " </stringConstant>\n")
    mid_file.seek(0)
    my_compiler_engine = CompilationEngine(mid_file, output_file)
    my_compiler_engine.compile_class()
    mid_file.close()

if "__main__" == __name__:
    # Parses the input path and calls assemble_file on each input file
    if not len(sys.argv) == 2:
        sys.exit("Invalid usage, please use: JackCompiler <input path>")
    argument_path = os.path.abspath(sys.argv[1])
    if os.path.isdir(argument_path):
        files_to_assemble = [
            os.path.join(argument_path, filename)
            for filename in os.listdir(argument_path)]
    else:
        files_to_assemble = [argument_path]
    for input_path in files_to_assemble:
        filename, extension = os.path.splitext(input_path)
        if extension.lower() != ".jack":
            continue
        output_path = filename + ".vm"
        with open(input_path, 'r') as input_file, \
                open(output_path, 'w') as output_file:
            compile_file(input_file, output_file)
