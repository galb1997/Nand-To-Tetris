"""This file is part of nand2tetris, as taught in The Hebrew University,
and was written by Aviv Yaish according to the specifications given in  
https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0 
Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/).
"""
import typing

C_POP = "C_POP"
A_COMMAND = "@"
TEMP = "temp"
LOCAL = "local"
ARGUMENT = "argument"
CONSTANT = "constant"
POINTER = "pointer"
THAT = "that"
THIS = "this"
STATIC = "static"
C_PUSH = "C_PUSH"
PUSH_END = ["@SP\n", "A=M\n", "M=D\n", "@SP\n", "M=M+1\n"]
PUSH_DIR = {LOCAL: ["D=A\n", "@LCL\n", "A=M+D\n", "D=M\n"],
            THAT: ["D=A\n", "@THAT\n", "A=M+D\n", "D=M\n"],
            THIS: ["D=A\n", "@THIS\n", "A=M+D\n", "D=M\n"],
            ARGUMENT: ["D=A\n", "@ARG\n", "A=M+D\n", "D=M\n"],
            CONSTANT: ["D=A\n"], TEMP: ["D=A\n", "@5\n", "A=D+A\n", "D=M\n"],
            STATIC: ["D=M\n"],
            POINTER: ["D=A\n", "@3\n", "A=D+A\n", "D=M\n"]}
POP_START = ["@SP\n", "A=M-1\n", "D=M\n", "@SP\n", "M=M-1\n", "@13\n", "M=D\n"]
POP_DIR = {LOCAL: ["D=A\n", "@LCL\n", "D=M+D\n", "@14\n", "M=D\n", "@13\n",
                   "D=M\n", "@14\n", "A=M\n", "M=D\n"],
           THAT: ["D=A\n", "@THAT\n", "D=M+D\n", "@14\n", "M=D\n", "@13\n",
                  "D=M\n", "@14\n", "A=M\n", "M=D\n"],
           THIS: ["D=A\n", "@THIS\n", "D=M+D\n", "@14\n", "M=D\n", "@13\n",
                  "D=M\n", "@14\n", "A=M\n", "M=D\n"],
           ARGUMENT: ["D=A\n", "@ARG\n", "D=M+D\n", "@14\n", "M=D\n", "@13\n",
                      "D=M\n", "@14\n", "A=M\n", "M=D\n"],
           TEMP: ["D=A\n", "@5\n", "D=D+A\n", "@14\n", "M=D\n", "@13\n",
                  "D=M\n", "@14\n", "A=M\n", "M=D\n"],
           POINTER: ["D=A\n", "@3\n", "D=D+A\n", "@14\n", "M=D\n", "@13\n",
                     "D=M\n", "@14\n", "A=M\n", "M=D\n"]}
ARITHMETIC1_DIR = {"add": ["@SP\n", "A=M-1\n", "D=M\n", "@SP\n", "A=M-1\n",
                           "A=A-1\n", "M=M+D\n", "@SP\n", "M=M-1\n"],
                   "sub": ["@SP\n", "A=M-1\n", "D=M\n", "@SP\n", "A=M-1\n",
                           "A=A-1\n", "M=M-D\n", "@SP\n", "M=M-1\n"],
                   "or": ["@SP\n", "A=M-1\n", "D=M\n", "@SP\n", "A=M-1\n",
                          "A=A-1\n", "M=D|M\n", "@SP\n", "M=M-1\n"],
                   "not": ["@SP\n", "A=M-1\n", "M=!M\n"],
                   "and": ["@SP\n", "A=M-1\n", "D=M\n", "@SP\n", "A=M-1\n",
                           "A=A-1\n", "M=D&M\n", "@SP\n", "M=M-1\n"],
                   "neg": ["@SP\n", "A=M-1\n", "D=M\n", "M=M-D\n", "M=M-D\n"]}
SHIFT_DIR = {"shiftleft": ["@SP\n", "A=M-1\n", "M=M<<\n"],
             "shiftright": ["@SP\n", "A=M-1\n", "M=M>>\n"]}


class CodeWriter:
    """Translates VM commands into Hack assembly code."""

    def __init__(self, output_stream: typing.TextIO) -> None:
        """Initializes the CodeWriter.

        Args:
            output_stream (typing.TextIO): output stream.
        """
        self._output_file = output_stream
        self._file_name = ""
        self._counter = 0
        self._call_counter = 0
        self._function_name = ""

    def set_file_name(self, filename: str) -> None:
        """Informs the code writer that the translation of a new VM file is 
        started.

        Args:
            filename (str): The name of the VM file.
        """
        self._file_name = filename

    def get_arithmetic2(self, key: str) -> []:
        """
        this function gets the right assembly command to 3 vm commands: eq, lt, gt
        :param key: the required vm command
        :return: the fit assembly command
        """
        arithmetic2_dir = {"eq": ["@SP\n", "A=M-1\n", "D=M\n",
                                  "@LABEL 1 " + self._file_name + str(self._counter) + "\n", "D;JGT\n",
                                  "@SP\n", "A=M-1\n",
                                  "A=A-1\n", "D=M\n",
                                  "@LABEL 2 " + self._file_name + str(self._counter) +  "\n",
                                  "D;JLT\n", "@FALSE " + self._file_name + str(self._counter) + "\n",
                                  "0;JMP\n",
                                  "(LABEL 1 " + self._file_name + str(self._counter) + ")\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "D=M\n",
                                  "@LABEL 2 " + self._file_name + str(self._counter) + "\n",
                                  "D;JGT\n", "@FALSE " + self._file_name + str(self._counter) + "\n",
                                  "0;JMP\n",
                                  "(LABEL 2 " + self._file_name + str(self._counter) + ")\n",
                                  "@SP\n", "A=M-1\n", "D=M\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "D=M-D\n", "@TRUE " + self._file_name + str(self._counter) + "\n",
                                  "D;JEQ\n", "(FALSE " + self._file_name + str(self._counter) + ")\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "M=0\n", "@END " + self._file_name + str(self._counter) + "\n",
                                  "0;JMP\n", "(TRUE " + self._file_name + str(self._counter) + ")\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "M=-1\n", "(END " + self._file_name + str(self._counter) + ")\n",
                                  "@SP\n", "M=M-1\n"],

                           "lt": ["@SP\n", "A=M-1\n", "D=M\n",
                                  "@LABEL 1 " + self._file_name + str(self._counter) + "\n",
                                  "D;JGT\n",
                                  "@SP\n", "A=M-1\n",
                                  "A=A-1\n", "D=M\n",
                                  "@LABEL 2 " + self._file_name + str(self._counter) + "\n",
                                  "D;JLT\n", "@FALSE " + self._file_name + str(self._counter) + "\n",
                                  "0;JMP\n",
                                  "(LABEL 1 " + self._file_name + str(self._counter) + ")\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "D=M\n",
                                  "@LABEL 2 " + self._file_name + str(self._counter) + "\n",
                                  "D;JGT\n", "@TRUE " + self._file_name + str(self._counter) + "\n",
                                  "0;JMP\n",
                                  "(LABEL 2 " + self._file_name + str(self._counter) + ")\n",
                                  "@SP\n", "A=M-1\n", "D=M\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "D=M-D\n", "@TRUE " + self._file_name + str(self._counter) + "\n",
                                  "D;JLT\n", "(FALSE " + self._file_name + str(self._counter) + ")\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "M=0\n", "@END " + self._file_name + str(self._counter) + "\n",
                                  "0;JMP\n", "(TRUE " + self._file_name + str(self._counter) + ")\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "M=-1\n", "(END " + self._file_name + str(self._counter) + ")\n",
                                  "@SP\n", "M=M-1\n"],

                           "gt": ["@SP\n", "A=M-1\n", "D=M\n",
                                  "@LABEL 1 " + self._file_name + str(self._counter) + "\n",
                                  "D;JGT\n",
                                  "@SP\n", "A=M-1\n",
                                  "A=A-1\n", "D=M\n",
                                  "@LABEL 2 " + self._file_name + str(self._counter) + "\n",
                                  "D;JLT\n", "@TRUE " + self._file_name + str(self._counter) + "\n",
                                  "0;JMP\n",
                                  "(LABEL 1 " + self._file_name + str(self._counter) + ")\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "D=M\n",
                                  "@LABEL 2 " + self._file_name + str(self._counter) + "\n",
                                  "D;JGT\n", "@FALSE " + self._file_name + str(self._counter) + "\n",
                                  "0;JMP\n",
                                  "(LABEL 2 " + self._file_name + str(self._counter) + ")\n",
                                  "@SP\n", "A=M-1\n", "D=M\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "D=M-D\n", "@TRUE " + self._file_name + str(self._counter) + "\n",
                                  "D;JGT\n", "(FALSE " + self._file_name + str(self._counter) + ")\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "M=0\n", "@END " + self._file_name + str(self._counter) + "\n",
                                  "0;JMP\n", "(TRUE " + self._file_name + str(self._counter) + ")\n", "@SP\n",
                                  "A=M-1\n",
                                  "A=A-1\n", "M=-1\n", "(END " + self._file_name + str(self._counter) + ")\n",
                                  "@SP\n", "M=M-1\n"]}
        return arithmetic2_dir[key]

    def write_arithmetic(self, command: str) -> None:
        """Writes the assembly code that is the translation of the given 
        arithmetic command.

        Args:
            command (str): an arithmetic command.
        """
        self._counter += 1
        self._output_file.write("//" + command + "\n")
        to_write = []
        if command in ["gt", "lt", "eq"]:
            to_write += self.get_arithmetic2(command)
        elif command in ["shiftleft", "shiftright"]:
            to_write += SHIFT_DIR[command]
        else:
            to_write += ARITHMETIC1_DIR[command]
        self._output_file.writelines(to_write)

    def write_push_pop(self, command: str, segment: str, index: int) -> None:
        """Writes the assembly code that is the translation of the given 
        command, where command is either C_PUSH or C_POP.

        Args:
            command (str): "C_PUSH" or "C_POP".
            segment (str): the memory segment to operate on.
            index (int): the index in the memory segment.
        """
        to_write = []
        self._output_file.write("//" + command + " " + segment + " " + str(index) + "\n")
        if command == C_PUSH:
            if segment == STATIC:
                to_write.append(A_COMMAND + self._file_name + "." + str(index) + "\n")
            else:
                to_write.append(A_COMMAND + str(index) + "\n")
            to_write += PUSH_DIR[segment]
            to_write += PUSH_END

        if command == C_POP:
            to_write += POP_START
            if segment == STATIC:
                to_write += ["@13\n", "D=M\n", "@" + self._file_name +
                             "." + str(index) + "\n", "M=D\n"]
            else:
                to_write.append("@" + str(index) + "\n")
                to_write += POP_DIR[segment]
        self._output_file.writelines(to_write)

    def write_init(self) -> None:
        # SP=256
        to_write = ["@256\n", "D=A\n", "@SP\n", "M=D\n"]
        self._output_file.writelines(to_write)
        # Call Sys.init
        self.write_call("Sys.init", 0)

    def write_label(self, label: str) -> None:
        self._output_file.write("//" + "label " + label + "\n")
        self._output_file.write("(" + self._function_name +
                                "$" + label + ")\n")

    def write_goto(self, label: str) -> None:
        self._output_file.write("//" + "goto " + label + "\n")
        # self._output_file.write("@SP\n")
        # self._output_file.write("M=M-1\n")
        self._output_file.write("@" + self._function_name +
                                "$" + label + "\n")
        self._output_file.write("0;JMP\n")

    def write_if(self, label: str) -> None:
        self._output_file.write("//" + "if-goto " + label + "\n")
        to_write = ["@SP\n", "A=M-1\n", "D=M\n","@SP\n", "M=M-1\n", "@" + self._function_name +
                                "$" + label + "\n" ,"D;JNE\n",
                ]
        self._output_file.writelines(to_write)

    def write_function(self, function_name: str, num_vars: int) -> None:
        # (function_name)
        self._function_name = function_name
        self._output_file.write("//" + "function " + function_name + "\n")
        self._output_file.write("(" + function_name + ")\n")
        # repeat num_vars time: push 0
        for i in range(0, num_vars):
            self.write_push_pop(C_PUSH, CONSTANT, 0)

    def write_call(self, function_name: str, num_args: int) -> None:
        # push return address
        self._output_file.write("//" + "call " + function_name + "\n")
        return_address = self._file_name + "$ret." + str(self._call_counter)
        command1 = ["@" + return_address + "\n", "D=A\n", "@SP\n", "A=M\n", "M=D\n",
                    "@SP\n", "M=M+1\n"]
        self._output_file.writelines(command1)

        # push LCL
        push_lcl = \
            ["@LCL\n", "D=M\n", "@SP\n", "A=M\n", "M=D\n", "@SP\n", "M=M+1\n"]
        self._output_file.writelines(push_lcl)

        # push ARG
        push_arg = \
            ["@ARG\n", "D=M\n", "@SP\n", "A=M\n", "M=D\n", "@SP\n", "M=M+1\n"]
        self._output_file.writelines(push_arg)

        # push THIS
        self.write_push_pop("C_PUSH", "pointer", 0)

        # push THAT
        self.write_push_pop("C_PUSH", "pointer", 1)

        # ARG = SP-5-num_args
        command5 = ["@SP\n", "D=M\n", "@5\n", "D=D-A\n", "@" + str(num_args) + "\n",
                    "D=D-A\n", "@ARG\n", "M=D\n"]
        self._output_file.writelines(command5)

        # LCL = SP
        command6 = ["@SP\n", "D=M\n", "@LCL\n", "M=D\n"]
        self._output_file.writelines(command6)

        # goto function_name
        self._output_file.write("//" + "goto " + function_name + "\n")
        command7 = ["@" + function_name + "\n", "0;JMP\n"]
        self._output_file.writelines(command7)

        # (return_address)
        self._output_file.write("(" + return_address + ")\n")
        self._call_counter += 1

    def write_return(self) -> None:
        self._output_file.write("//return\n")
        command0 = ["@LCL\n", "D=M\n", "@5\n", "A=D-A\n", "D=M\n" "@15\n", "M=D\n"]
        self._output_file.writelines(command0)

        # *ARG = pop
        self.write_push_pop(C_POP, ARGUMENT, 0)

        # end_frame = LCL
        command1 = ["@LCL\n", "D=M\n", "@13\n", "M=D\n"]
        self._output_file.writelines(command1)

        # ret_addr = *(end_frame - 5)
        command2 = ["@15\n", "D=M\n", "@14\n", "M=D\n"]
        self._output_file.writelines(command2)

        # SP = ARG + 1
        command4 = ["@ARG\n" "D=M+1\n" "@SP\n" "M=D\n"]
        self._output_file.writelines(command4)

        # THAT = *(end_frame -1)
        command5 = ["@13\n", "A=M-1\n", "D=M\n", "@THAT\n", "M=D\n"]
        self._output_file.writelines(command5)

        # THIS = *(end_frame -2)
        command6 = ["@13\n", "D=M\n", "@2\n", "A=D-A\n", "D=M\n", "@THIS\n", "M=D\n"]
        self._output_file.writelines(command6)

        # ARG = *(end_frame -3)
        command7 = ["@13\n", "D=M\n", "@3\n", "A=D-A\n", "D=M\n", "@ARG\n", "M=D\n"]
        self._output_file.writelines(command7)

        # LCL = *(end_frame -4)
        command8 = ["@13\n", "D=M\n", "@4\n", "A=D-A\n", "D=M\n", "@LCL\n", "M=D\n"]
        self._output_file.writelines(command8)

        # goto ret_addr
        command9 = ["@14\n", "A=M\n", "0;JMP\n"]
        self._output_file.writelines(command9)

    def close(self) -> None:
        """Closes the output file."""
        self._output_file.close()
