"""This file is part of nand2tetris, as taught in The Hebrew University,
and was written by Aviv Yaish according to the specifications given in  
https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0 
Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/).
"""
import os
import sys
import typing
from Parser import Parser
from CodeWriter import CodeWriter

C_POP = "C_POP"
C_PUSH = "C_PUSH"
C_ARITHMETIC = "C_ARITHMETIC"
C_LABEL = "C_LABEL"
C_GOTO = "C_GOTO"
C_IF = "C_IF"
C_FUNCTION = "C_FUNCTION"
C_RETURN = "C_RETURN"
C_CALL = "C_CALL"

files_counter = 0


def translate_file(
        input_file: typing.TextIO, output_file: typing.TextIO) -> None:
    """Translates a single file.

    Args:
        input_file (typing.TextIO): the file to translate.
        output_file (typing.TextIO): writes all output to this file.
    """
    # Your code goes here!
    # Note: you can get the input file's name using:
    input_filename, input_extension = \
        os.path.splitext(os.path.basename(input_file.name))
    my_parser = Parser(input_file)
    my_code_writer = CodeWriter(output_file)
    my_code_writer.set_file_name(input_filename)
    global files_counter
    if files_counter == 0:
        my_code_writer.write_init()

    while my_parser.has_more_commands():
        my_parser.advance()
        command = my_parser.command_type()

        if command == C_RETURN:
            my_code_writer.write_return()

        else:
            arg1 = my_parser.arg1()
            if command in [C_POP, C_PUSH, C_FUNCTION, C_CALL]:
                arg2 = my_parser.arg2()
                if command in [C_POP, C_PUSH]:
                    my_code_writer.write_push_pop(command, arg1, arg2)
                if command == C_FUNCTION:
                    my_code_writer.write_function(arg1, arg2)
                if command == C_CALL:
                    my_code_writer.write_call(arg1, arg2)

            if command == C_ARITHMETIC:
                my_code_writer.write_arithmetic(arg1)
            if command == C_GOTO:
                my_code_writer.write_goto(arg1)
            if command == C_IF:
                my_code_writer.write_if(arg1)
            if command == C_LABEL:
                my_code_writer.write_label(arg1)

    files_counter += 1
    #my_code_writer.close()


if "__main__" == __name__:
    # Parses the input path and calls translate_file on each input file
    if not len(sys.argv) == 2:
        sys.exit("Invalid usage, please use: VMtranslator <input path>")
    argument_path = os.path.abspath(sys.argv[1])
    if os.path.isdir(argument_path):
        files_to_translate = [
            os.path.join(argument_path, filename)
            for filename in os.listdir(argument_path)]
        output_path = os.path.join(argument_path, os.path.basename(
            argument_path))
    else:
        files_to_translate = [argument_path]
        output_path, extension = os.path.splitext(argument_path)
    output_path += ".asm"
    with open(output_path, 'w') as output_file:
        for input_path in files_to_translate:
            filename, extension = os.path.splitext(input_path)
            if extension.lower() != ".vm":
                continue
            with open(input_path, 'r') as input_file:
                translate_file(input_file, output_file)
    output_file.close()
